package com.scj.beilu.app.mvp.find.publishstatus;

import com.mx.pro.lib.mvp.MvpView;
import com.mx.pro.lib.mvp.network.config.BaseMvpPresenter;

/**
 * author:SunGuiLan
 * date:2019/1/31
 */
public class PublishWayPre extends BaseMvpPresenter<PublishWayPre.PublishWayView> {
    public interface PublishWayView extends MvpView {
    }
}
