package com.scj.beilu.app.ui.act;

/**
 * @author Mingxun
 * @time on 2019/1/11 15:50
 */
public class LaunchAct {
}
