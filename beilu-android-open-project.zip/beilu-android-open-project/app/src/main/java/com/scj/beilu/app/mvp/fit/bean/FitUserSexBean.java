package com.scj.beilu.app.mvp.fit.bean;

import com.scj.beilu.app.mvp.common.bean.ResultMsgBean;

/**
 * @author Mingxun
 * @time on 2019/3/11 14:44
 */
public class FitUserSexBean extends ResultMsgBean {


    /**
     * userSex : -1
     */

    private int userSex;

    public int getUserSex() {
        return userSex;
    }

    public void setUserSex(int userSex) {
        this.userSex = userSex;
    }
}
