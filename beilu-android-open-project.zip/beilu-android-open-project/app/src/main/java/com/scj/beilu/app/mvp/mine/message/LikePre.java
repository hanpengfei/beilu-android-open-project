package com.scj.beilu.app.mvp.mine.message;

import com.mx.pro.lib.mvp.MvpView;
import com.mx.pro.lib.mvp.network.config.BaseMvpPresenter;

/**
 * @author Mingxun
 * @time on 2019/1/14 19:54
 */
public class LikePre extends BaseMvpPresenter<LikePre.LikeView> {
    public interface LikeView extends MvpView {

    }
}
