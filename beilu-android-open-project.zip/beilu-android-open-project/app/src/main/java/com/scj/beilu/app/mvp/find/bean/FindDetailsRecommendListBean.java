package com.scj.beilu.app.mvp.find.bean;

import java.util.List;

/**
 * @author Mingxun
 * @time on 2019/2/22 19:53
 */
public class FindDetailsRecommendListBean {
    private List<FindDetailsRecommendBean> mFindDetailsRecommendBeanList;
}
