package com.scj.beilu.app.mvp.home;

import com.mx.pro.lib.mvp.MvpView;
import com.mx.pro.lib.mvp.network.config.BaseMvpPresenter;

/**
 * author:SunGuiLan
 * date:2019/2/16
 * descriptin:
 */
public class HomeAtionPre extends BaseMvpPresenter<HomeAtionPre.HomeActionView> {
    public interface HomeActionView extends MvpView {
    }
}
