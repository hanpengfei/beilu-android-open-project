package com.scj.beilu.app.mvp.base;

import com.mx.pro.lib.mvp.MvpView;

/**
 * @author Mingxun
 * @time on 2019/1/15 21:22
 */
public interface TabView extends MvpView {
}
