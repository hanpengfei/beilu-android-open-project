package com.scj.beilu.app.mvp.home.selller;

import com.mx.pro.lib.mvp.MvpView;
import com.mx.pro.lib.mvp.network.config.BaseMvpPresenter;

/**
 * author:SunGuiLan
 * date:2019/2/18
 * descriptin:
 */
public class CoachAlbumPre extends BaseMvpPresenter<CoachAlbumPre.CoachAlbumView> {
    public interface  CoachAlbumView extends MvpView{

    }
}
