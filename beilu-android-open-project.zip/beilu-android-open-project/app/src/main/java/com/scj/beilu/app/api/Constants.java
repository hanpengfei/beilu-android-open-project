package com.scj.beilu.app.api;

/**
 * @author Mingxun
 * @time on 2019/2/19 15:22
 */
public class Constants {
    public static final String VAL_SHOW_CREATE_HINT = "dialog_hint";
    public static final int REQUEST_CODE_CHOOSE = 0 * 102;
    public static final int REQUEST_CODE_CHOOSE1 = 0 * 102;
    public static final String WXAPPID = "wxec4fad924ee5fd9e";
    public static final String DIRECTORY = "beilu";
}
