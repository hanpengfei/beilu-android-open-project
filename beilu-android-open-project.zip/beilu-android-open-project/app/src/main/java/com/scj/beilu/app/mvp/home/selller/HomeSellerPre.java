package com.scj.beilu.app.mvp.home.selller;

import com.mx.pro.lib.mvp.MvpView;
import com.mx.pro.lib.mvp.network.config.BaseMvpPresenter;

/**
 * author:SunGuiLan
 * date:2019/2/14
 * descriptin:
 */
public class HomeSellerPre extends BaseMvpPresenter<HomeSellerPre.HomeSellerView> {
    public interface HomeSellerView extends MvpView {

    }
}
