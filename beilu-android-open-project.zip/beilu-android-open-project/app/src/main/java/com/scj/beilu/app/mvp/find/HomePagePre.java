package com.scj.beilu.app.mvp.find;

import com.mx.pro.lib.mvp.MvpView;
import com.mx.pro.lib.mvp.network.config.BaseMvpPresenter;

/**
 * author:SunGuiLan
 * date:2019/2/10
 * descriptin:
 */
public class HomePagePre extends BaseMvpPresenter<HomePagePre.HomePageView> {
    public interface HomePageView extends MvpView {

    }
}
