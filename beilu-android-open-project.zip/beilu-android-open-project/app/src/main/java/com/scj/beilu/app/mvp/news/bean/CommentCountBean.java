package com.scj.beilu.app.mvp.news.bean;

import com.scj.beilu.app.mvp.common.bean.ResultMsgBean;

/**
 * @author Mingxun
 * @time on 2019/2/15 22:52
 */
public class CommentCountBean extends ResultMsgBean {
    private int newsCommentCount;

    public int getNewsCommentCount() {
        return newsCommentCount;
    }
}
