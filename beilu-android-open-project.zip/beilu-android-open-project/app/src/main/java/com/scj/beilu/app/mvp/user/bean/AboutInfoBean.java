package com.scj.beilu.app.mvp.user.bean;

import com.scj.beilu.app.mvp.common.bean.ResultMsgBean;

/**
 * @author Mingxun
 * @time on 2019/4/24 22:38
 */
public class AboutInfoBean extends ResultMsgBean {
}
