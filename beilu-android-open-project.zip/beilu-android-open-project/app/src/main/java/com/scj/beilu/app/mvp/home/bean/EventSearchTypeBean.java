package com.scj.beilu.app.mvp.home.bean;

/**
 * @author Mingxun
 * @time on 2019/4/12 02:53
 */
public class EventSearchTypeBean {
    public int index;
    public String keyName;

    public EventSearchTypeBean(int index, String keyName) {
        this.index = index;
        this.keyName = keyName;
    }
}
