package com.scj.beilu.app.ui.find;

/**
 * @author Mingxun
 * @time on 2019/4/24 20:52
 */
public interface AttentionListener {
    void onAttention(int index, int userId);
}
