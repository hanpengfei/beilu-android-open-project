package com.scj.beilu.app.mvp.home.selller;

import com.mx.pro.lib.mvp.MvpView;
import com.mx.pro.lib.mvp.network.config.BaseMvpPresenter;

/**
 * author:SunGuiLan
 * date:2019/2/19
 * descriptin:
 */
public class ShopPhotoDetalisPre extends BaseMvpPresenter<ShopPhotoDetalisPre.ShopPhotoDetalisView> {
    public interface ShopPhotoDetalisView extends MvpView {
    }
}
